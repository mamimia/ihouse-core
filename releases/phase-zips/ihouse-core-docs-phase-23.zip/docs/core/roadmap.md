# iHouse Core — Roadmap (Future Phases)

## Purpose
This document is the canonical forward plan for iHouse Core phases beyond the latest closed phase.
It is not history. History lives in docs/core/phase-timeline.md.

This roadmap may evolve but must never violate the core invariants.

---

## Phase 21 — Deterministic Replay Tooling

Goal:
Provide safe operational replay tools without bypassing the canonical apply gate.

Scope:
1) Replay by tenant
2) Replay by property
3) Replay by booking
4) Deterministic output verification

Safety rules:
Replay must never bypass tenant isolation.
Replay must never mutate canonical truth outside apply_envelope.

Exit criteria:
1) Replay functions exist and are documented
2) Replay output is deterministic
3) Replay cannot violate tenant isolation

---

## Phase 22 — External Ingestion Hardening

Goal:
Stabilize ingestion from external producers (OTA, admin tools, manual bookings).

Scope:
1) Canonical envelope validation per event kind
2) Deterministic rejection behavior
3) External producer adapters

Exit criteria:
1) At least one OTA ingestion path validated
2) Deterministic rejection codes documented
3) External ingestion cannot bypass canonical gate

---

## Phase 23 — External Event Semantics Hardening

Goal:
Protect the canonical system from semantic errors in external booking events.

Scope:
1) Business idempotency rules beyond transport retries
2) Booking lifecycle semantic validation
3) Ordering tolerance rules for external events
4) Stronger channel normalization discipline

Exit criteria:
1) Duplicate business events are handled deterministically
2) Invalid lifecycle transitions are rejected deterministically
3) External ordering edge cases are formally defined
4) Adapter semantics are documented and enforced

---

## Phase 24 — Ordering and Reconciliation Strategy

Goal:
Make the system tolerant to delayed, missing, or out-of-order external events.

Scope:
1) Out-of-order event handling policy
2) Pending event or reconciliation strategy
3) Deterministic conflict handling
4) Clear business-time vs system-time policy

Exit criteria:
1) Out-of-order events cannot corrupt projections
2) Reconciliation path is defined
3) Event ordering rules are documented
4) Deterministic handling is verified

---

## Phase 25 — External Integration Hardening

Goal:
Strengthen operational safety for real external channel integrations.

Scope:
1) Webhook or channel authentication hardening
2) Rate limiting and retry controls
3) Audit logging for external ingestion
4) Dead-letter strategy for failed external events

Exit criteria:
1) External integrations are observable and auditable
2) Failed external events are preserved safely
3) Retry storms cannot silently corrupt ingest behavior
4) Channel trust boundaries are enforced

---

## Phase 26 — Replay and Projection Operations

Goal:
Provide safe operational rebuild and replay tooling for a growing event log.

Scope:
1) Replay by tenant / property / booking
2) Projection rebuild verification
3) Replay diagnostics
4) Optional snapshot planning for future scale

Exit criteria:
1) Replay tooling exists and is documented
2) Projection rebuild can be verified deterministically
3) Operators can diagnose replay and rebuild issues
4) Future snapshot path is defined without breaking canonical invariants
