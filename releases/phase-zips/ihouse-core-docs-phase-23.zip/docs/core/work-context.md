# iHouse Core — Work Context

Current Phase
Phase 23 — External Event Semantics Hardening (Open)

Last Closed Phase
Phase 22 — OTA Ingestion Boundary (Closed)

Primary Objective

Strengthen the semantic correctness of external booking events
after the OTA ingestion boundary was introduced.

Focus areas

1) Business idempotency protection beyond envelope transport idempotency.

2) Ordering tolerance for external events that may arrive out of order.

3) Event semantic validation for booking lifecycle transitions.

4) Channel normalization consistency across OTA providers.

Constraints

- event_log remains the only source of truth.
- booking_state remains projection-only.
- All external ingestion must pass through the adapter boundary.
- Replay safety must remain preserved.

Phase 23 Deliverables

- deterministic external event ordering strategy
- business idempotency safeguards
- lifecycle validation rules for booking events
- expanded adapter validation rules