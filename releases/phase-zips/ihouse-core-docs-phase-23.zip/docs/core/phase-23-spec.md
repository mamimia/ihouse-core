# iHouse Core — Phase 23 Specification

## Phase
Phase 23 — External Event Semantics Hardening

## Objective
Strengthen the semantic correctness of external booking events after the OTA ingestion boundary was introduced in Phase 22.

The goal of this phase is not to create a new ingestion path.
The goal is to make sure external events are semantically safe before they mutate the canonical system.

## Why This Phase Exists

Phase 22 established the adapter boundary:

External payload
→ adapter normalization
→ canonical envelope
→ canonical ingest API
→ deterministic event kernel

That boundary now exists.

However, external systems introduce semantic risks that transport idempotency alone does not solve:

- duplicate business events with different request IDs
- out-of-order booking lifecycle events
- inconsistent external provider semantics
- invalid booking transitions

Phase 23 addresses those risks.

## Canonical Constraints

1. event_log remains the only source of truth.
2. booking_state remains projection-only.
3. apply_envelope remains the only allowed write gate.
4. external systems must never write directly to event_log or booking_state.
5. replay safety must remain preserved.

## Scope

### 1. Business Idempotency Hardening

Transport idempotency prevents duplicate application of the same envelope.

Phase 23 must also define business-level idempotency protection for logically duplicate external booking events.

Examples:
- same booking created multiple times under different transport retries
- semantically identical external events with different provider delivery IDs

Focus:
- define stable business identity for duplicate protection
- define when two external events should be considered the same business event
- ensure deterministic handling

### 2. Booking Lifecycle Validation

External channels may send semantically invalid transitions.

Examples:
- BOOKING_CANCELED before booking exists
- repeated cancellation after terminal cancellation
- update after terminal cancellation without explicit reopen policy

Phase 23 must define allowed and rejected lifecycle transitions.

### 3. Ordering Tolerance Rules

External providers may deliver events out of order.

Examples:
- modified before created
- canceled before created
- delayed create after later terminal state

Phase 23 must define a deterministic policy for:
- reject
- buffer
- reconcile
- tolerate

This phase may define the policy even if the full operational implementation is deferred to a later phase.

### 4. Channel Semantic Normalization Discipline

Channel adapters must preserve canonical semantics.

Areas that may require stronger rules:
- provider status normalization
- date range normalization
- reservation identity normalization
- guest metadata normalization
- timezone handling

## Deliverables

1. Business idempotency policy
2. Booking lifecycle transition policy
3. Ordering tolerance policy
4. Adapter semantic normalization rules
5. Updated validation rules where needed
6. Documentation aligned with the new semantics

## Explicit Non-Goals

This phase must not:
- create a second write path
- bypass apply_envelope
- mutate booking_state directly from application code
- introduce analytics projections
- introduce revenue projections
- introduce snapshotting as a runtime requirement

## Exit Criteria

Phase 23 is complete when:

1. duplicate external business events are handled deterministically
2. invalid booking lifecycle transitions are rejected deterministically
3. ordering tolerance policy is explicitly defined
4. adapter semantic rules are documented and enforced
5. no new persistence path is introduced
6. replay safety remains preserved

## Success Condition

At the end of Phase 23, the system should not only ingest external events safely,
but also interpret them safely at the business-semantics level.
