"""
iHouse Core — FastAPI Application Entrypoint
=============================================

This is the unified production entrypoint for the OTA webhook ingestion stack.

Routes:
    GET  /health                — liveness check (no auth)
    POST /webhooks/{provider}  — OTA webhook ingestion (Phase 58)

Middleware:
    Phase 60 — Structured request logging  ✅
    Phase 61 — JWT auth (tenant_id from token)
    Phase 62 — Per-tenant rate limiting

Run locally:
    PYTHONPATH=src uvicorn main:app --reload --port 8000

Or via this file directly:
    PYTHONPATH=src python src/main.py
"""
from __future__ import annotations

import logging
import os
import time
import uuid
from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from api.webhooks import router as webhooks_router
from api.health import run_health_checks
from schemas.responses import ErrorResponse, HealthResponse

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger("ihouse-core")

# ---------------------------------------------------------------------------
# Lifespan (startup / shutdown)
# ---------------------------------------------------------------------------

_ENV = os.getenv("IHOUSE_ENV", "development")


@asynccontextmanager
async def lifespan(app: FastAPI):  # noqa: ANN001
    logger.info("iHouse Core API starting — env=%s version=%s", _ENV, app.version)
    yield
    logger.info("iHouse Core API shutting down")


# ---------------------------------------------------------------------------
# App
# ---------------------------------------------------------------------------

_DESCRIPTION = """
## iHouse Core — OTA Webhook Ingestion API

Canonical event pipeline for property management.
All OTA provider webhooks enter the system through this API,
passing through signature verification, JWT auth, rate limiting,
and payload validation before being written to the event log.

### Request Flow

```
POST /webhooks/{provider}
  → HMAC signature verification   (403)
  → JWT auth (tenant_id from sub) (403)
  → Per-tenant rate limiting      (429 + Retry-After)
  → Payload validation            (400)
  → Canonical event pipeline      (200 + idempotency_key)
```

### Authentication

All webhook endpoints require a valid **Bearer JWT** token.
The `sub` claim is used as `tenant_id`.
In development mode (`IHOUSE_JWT_SECRET` not set), auth is bypassed.

### Supported Providers

`bookingcom` · `expedia` · `airbnb` · `agoda` · `tripcom`
"""

_TAGS = [
    {"name": "ops", "description": "Operational endpoints (health, status). No authentication required."},
    {"name": "webhooks", "description": "OTA provider webhook ingestion. JWT Bearer + HMAC signature required."},
    {"name": "financial", "description": "Financial facts query. JWT Bearer required. Reads from booking_financial_facts only."},
]

app = FastAPI(
    title="iHouse Core",
    version="0.1.0",
    description=_DESCRIPTION,
    contact={
        "name": "iHouse Engineering",
        "url": "https://github.com/mamimia/ihouse-core",
    },
    license_info={
        "name": "Proprietary",
    },
    openapi_tags=_TAGS,
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan,
)

# ---------------------------------------------------------------------------
# Routers
# ---------------------------------------------------------------------------

app.include_router(webhooks_router)

from api.financial_router import router as financial_router  # noqa: E402
app.include_router(financial_router)


# ---------------------------------------------------------------------------
# OpenAPI — inject BearerAuth security scheme (Phase 63)
# ---------------------------------------------------------------------------

def _custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    from fastapi.openapi.utils import get_openapi
    schema = get_openapi(
        title=app.title,
        version=app.version,
        description=app.description,
        contact=app.contact,
        license_info=app.license_info,
        tags=app.openapi_tags,
        routes=app.routes,
    )
    schema.setdefault("components", {}).setdefault("securitySchemes", {})["BearerAuth"] = {
        "type": "http",
        "scheme": "bearer",
        "bearerFormat": "JWT",
        "description": (
            "HMAC-HS256 signed JWT. The `sub` claim is used as `tenant_id`. "
            "Set `IHOUSE_JWT_SECRET` to enable; omit for dev-mode bypass."
        ),
    }
    app.openapi_schema = schema
    return app.openapi_schema


app.openapi = _custom_openapi  # type: ignore[method-assign]


# ---------------------------------------------------------------------------
# Middleware — Structured request logging (Phase 60)
# ---------------------------------------------------------------------------

@app.middleware("http")
async def request_logging(request: Request, call_next):  # type: ignore[name-defined]
    """
    Logs every request with:
      - unique request_id (UUID4)
      - method + path
      - status_code and duration_ms on exit

    Sets X-Request-ID response header on every response.
    """
    request_id = str(uuid.uuid4())
    request.state.request_id = request_id

    logger.info(
        "→ [%s] %s %s",
        request_id,
        request.method,
        request.url.path,
    )

    start = time.monotonic()
    try:
        response = await call_next(request)
    except Exception:  # noqa: BLE001
        duration_ms = int((time.monotonic() - start) * 1000)
        logger.exception(
            "← [%s] %s %s UNHANDLED_ERROR %dms",
            request_id,
            request.method,
            request.url.path,
            duration_ms,
        )
        from fastapi.responses import JSONResponse as _JSONResponse
        resp = _JSONResponse(status_code=500, content={"error": "INTERNAL_ERROR"})
        resp.headers["X-Request-ID"] = request_id
        return resp

    duration_ms = int((time.monotonic() - start) * 1000)
    logger.info(
        "← [%s] %s %s %d %dms",
        request_id,
        request.method,
        request.url.path,
        response.status_code,
        duration_ms,
    )
    response.headers["X-Request-ID"] = request_id
    return response


@app.get(
    "/health",
    tags=["ops"],
    summary="Liveness + dependency check",
    response_model=HealthResponse,
    responses={
        200: {"model": HealthResponse, "description": "ok or degraded (DLQ non-empty)"},
        503: {"model": HealthResponse, "description": "Supabase unreachable"},
    },
)
async def health() -> JSONResponse:
    """
    Enhanced health check (Phase 64).

    Runs:
    - **Supabase ping** — SELECT 1 equivalent via REST API
    - **DLQ count** — unprocessed `ota_dead_letter` rows

    Status semantics:
    - `ok` — all checks pass, DLQ empty
    - `degraded` — checks pass but DLQ has unprocessed rows
    - `unhealthy` — Supabase unreachable → **503**
    """
    result = run_health_checks(version=app.version, env=_ENV)
    return JSONResponse(
        status_code=result.http_status,
        content={
            "status": result.status,
            "version": result.version,
            "env": result.env,
            "checks": result.checks,
        },
    )


# ---------------------------------------------------------------------------
# Local dev runner
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=int(os.getenv("PORT", "8000")),
        reload=os.getenv("IHOUSE_ENV", "development") == "development",
        log_level="info",
    )
