# iHouse Core — Current Snapshot

## Authority
Repository docs are authoritative.
Supabase runtime behavior is authoritative truth.
Chat output is never authoritative.

## Canonical Runtime
Canonical event source:
Supabase public.event_log

Single atomic write gate:
apply_envelope RPC
Idempotent by envelope_id
Replay returns ALREADY_APPLIED

Read model:
public.booking_state is a projection derived from event_log
It is the canonical real time read surface

## Availability Invariants
Scope:
(tenant_id, property_id)

Range semantics:
[check_in, check_out)

Valid stay:
check_out > check_in

Active for availability:
status IS DISTINCT FROM 'canceled'
NULL is treated as active for legacy rows

## Phase
Current:
Phase 20 – Envelope Event Identity Hardening + Replay Safety (Open)

Last closed:
Phase 19 – Event Version Discipline + DB Gate Validation (Closed)
