# iHouse Core – Work Context

## Current Active Phase

Phase 32 – OTA Ingestion Contract Test Verification


## Last Closed Phase

Phase 31 – OTA Ingestion Contract Verification


## Current Objective

Produce executable verification for the OTA-to-core runtime contract
already locked by Phases 30 and 31.

This phase exists to prove with tests and direct verification that the
live implementation still matches the explicit runtime handoff.

It is a verification and test-hardening phase only.

It is not a redesign phase.
It is not a reconciliation phase.
It is not an amendment phase.


## Locked Architectural Reality

The system remains a deterministic domain event execution kernel.

System truth is derived from canonical events.

booking_state is projection-only.

apply_envelope is the only authority allowed to mutate state.

Supabase is canonical.

External systems must never bypass the canonical apply gate.


## Permanent Invariants

- event_log is append-only
- events are immutable
- booking_state is derived from events only
- apply_envelope is the only write authority
- adapters must not read booking_state
- adapters must not reconcile booking history
- adapters must not mutate canonical state
- adapters must not bypass apply_envelope
- provider-specific logic must remain isolated from the shared pipeline
- MODIFY remains deterministic reject-by-default


## Current OTA Runtime Boundary

The runtime handoff verified in docs and code is:

ingest_provider_event
→ process_ota_event
→ canonical envelope
→ IngestAPI.append_event
→ CoreExecutor.execute
→ apply_envelope


## Phase 32 Scope

Allowed work:

- verify executable coverage for the OTA runtime contract
- verify the OTA service remains thin
- verify ordered shared-pipeline responsibilities
- verify core ingest rejects missing executor wiring
- verify CoreExecutor remains the only execution boundary
- verify replay uses the same public ingest contract
- add or tighten tests where real verification gaps are found

Disallowed work:

- reconciliation
- amendment handling
- OTA snapshot fetching
- out-of-order buffering
- booking_state reads inside adapters
- alternative write paths
- direct apply_envelope calls from OTA code
- new canonical event kinds
- reopening Phase 28 decisions


## Immediate Working Rule

Do not redesign the architecture.

Do not reopen closed phases.

Do only the minimum work required to verify and harden executable proof
for the OTA ingestion contract.
