# iHouse Core – Current Snapshot

Current Phase
Phase 32 – OTA Ingestion Contract Test Verification

Last Closed Phase
Phase 31 – OTA Ingestion Contract Verification


## System Status

The deterministic event architecture remains fully operational.

The canonical database gate (`apply_envelope`) remains the only
authority allowed to mutate booking state.

External systems interact with iHouse Core through the OTA ingestion
boundary and then the canonical core ingest path.


## Phase 31 Result

Phase 31 closed the OTA ingestion contract-verification loop at the
documentation and interface level without changing canonical business
semantics.

Phase 31 confirmed and aligned the live runtime handoff as:

ingest_provider_event
→ process_ota_event
→ canonical envelope
→ IngestAPI.append_event
→ CoreExecutor.execute
→ apply_envelope

Phase 31 completed the following:

- aligned current-state docs to the live runtime contract
- corrected contract-name drift from `IngestAPI.ingest` to `IngestAPI.append_event`
- clarified OTA service wording to describe envelopes as ready for core ingest
- archived closed phase specs consistently under `docs/archive/phases`
- introduced a dedicated future improvements backlog
- preserved append-only historical records without rewriting old history

No canonical business semantics changed.

No alternative write path was introduced.

MODIFY remains deterministic reject-by-default.


## Canonical External OTA Events

The canonical OTA lifecycle events remain:

- BOOKING_CREATED
- BOOKING_CANCELED


## Canonical Invariants

Event Store
- event_log is append-only
- events are immutable

State Model
- booking_state is projection-only
- booking_state is derived exclusively from events

Write Authority
- apply_envelope RPC is the only authority allowed to mutate booking state

Replay Safety
- duplicate envelopes must not create new events
- duplicate ingestion must remain idempotent


## Phase 32 Focus

Phase 32 focuses on executable verification of the OTA ingestion
contract already locked by Phases 30 and 31.

This phase is for test and verification hardening only.

It should verify with executable evidence that:

- OTA service entry remains thin
- shared OTA pipeline preserves ordered responsibilities
- core ingest rejects missing executor wiring
- CoreExecutor remains the only execution boundary
- replay assumptions align to the same public ingest contract
- no OTA path bypasses core ingest or executor

It must not redesign the architecture.
It must not reopen closed semantic decisions.
