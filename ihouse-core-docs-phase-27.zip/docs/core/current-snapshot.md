# iHouse Core – Current Snapshot

System Version  
Phase 27 – Multi-OTA Adapter Architecture (Active)

Last Closed Phase  
Phase 26 – OTA Provider Verification


## System Status

The deterministic event architecture remains fully operational.

The canonical database gate (`apply_envelope`) remains the only authority
allowed to mutate booking_state.

External systems interact with iHouse Core exclusively through the OTA
ingestion boundary.


## Phase 26 Result

Phase 26 verified OTA provider payload schemas to determine whether
modification events expose deterministic semantic subtypes.

Providers inspected:

Booking.com  
Expedia  
Airbnb  
Agoda  
Trip.com

Result:

No provider exposes a payload-only deterministic modification subtype
that safely supports mapping:

MODIFY → UPDATE

without booking_state lookup.

The canonical ingestion rule therefore remains unchanged:

MODIFY  
→ deterministic reject-by-default


## Canonical Invariants

Event Store
- event_log is append-only
- events are immutable

State Model
- booking_state is projection-only
- booking_state is derived exclusively from events

Write Authority
- apply_envelope RPC is the only authority allowed to mutate booking_state

Replay Safety
- duplicate envelopes must not create new events
- duplicate ingestion must remain idempotent


## OTA Boundary Status

OTA adapters perform:

- payload normalization
- semantic classification
- semantic validation
- canonical envelope creation


## Future Improvements

OTA Sync Recovery Layer

A future reconciliation system capable of:

- detecting modification notifications
- triggering provider reservation re-fetch
- comparing OTA state with local state
- emitting deterministic canonical events

This layer must remain outside the canonical ingestion pipeline.
