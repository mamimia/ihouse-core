# iHouse Core – Work Context

Current Phase  
Phase 27 – Multi-OTA Adapter Architecture

Last Closed Phase  
Phase 26 – OTA Provider Verification


## Phase 27 Objective

Introduce a scalable adapter architecture that supports multiple OTA
providers while preserving the deterministic ingestion pipeline.

This phase focuses on adapter structure and provider isolation.

The canonical event model and database gate remain unchanged.


## Architectural Constraints

The following invariants remain unchanged:

- apply_envelope remains the only authority allowed to mutate booking_state
- event_log remains append-only
- booking_state remains projection-only
- adapters must not perform booking_state lookup
- adapters must not reconcile booking history
- adapters must not mutate canonical state
- adapters must not bypass the canonical database gate


## Canonical OTA Event Surface

Currently supported deterministic external events:

BOOKING_CREATED  
BOOKING_CANCELED

OTA modification notifications remain classified as:

MODIFY

Current rule:

MODIFY  
→ deterministic reject-by-default


## Phase 27 Scope

Introduce a scalable adapter structure for multiple OTA providers.

Target providers:

Booking.com  
Expedia  
Airbnb  
Agoda  
Trip.com


## Non Goals

Phase 27 must NOT:

- introduce booking_state reads
- introduce reconciliation logic
- modify apply_envelope
- modify canonical schema
- reinterpret modification events


## Expected Outcome

Multiple OTA providers can integrate through a unified adapter
architecture while preserving deterministic event ingestion guarantees.
