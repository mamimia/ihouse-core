# Phase 27 – Multi-OTA Adapter Architecture

Objective

Introduce a scalable adapter architecture supporting multiple OTA
providers while preserving deterministic event ingestion.


Background

Phase 26 verified that OTA providers do not expose deterministic
modification subtypes within webhook payloads.

Therefore the canonical ingestion rule remains:

MODIFY
→ deterministic reject-by-default


Scope

This phase introduces a structured adapter architecture for:

Booking.com
Expedia
Airbnb
Agoda
Trip.com


Adapter Responsibilities

Adapters must:

- normalize provider payloads
- classify semantic event types
- validate payload structure
- construct canonical envelopes
- submit envelopes through apply_envelope


Adapter Restrictions

Adapters must NOT:

- perform booking_state lookup
- reconcile booking history
- infer modification semantics
- mutate canonical state
- bypass the database gate


Supported External Events

BOOKING_CREATED
BOOKING_CANCELED


Modification Events

OTA modification notifications remain classified as:

MODIFY

Current canonical rule:

MODIFY
→ deterministic reject-by-default


Expected Outcome

Multiple OTA providers integrate through a unified adapter boundary
while preserving the deterministic canonical event model.
