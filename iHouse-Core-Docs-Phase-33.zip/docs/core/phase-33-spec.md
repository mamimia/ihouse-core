# Phase 33 – OTA Retry Business Idempotency Discovery

## Status

Active

This file defines the active phase after Phase 32 closed.

## Depends On

Phase 32 – OTA Ingestion Contract Test Verification

Phase 33 begins only after the OTA runtime contract is already locked and
verified by executable evidence.

## Objective

Determine whether OTA-originated duplicate business events can bypass the
current envelope-level idempotency model by arriving with different
transport identifiers, and define the minimal canonical hardening direction
required before higher-volume OTA traffic.

This phase is a discovery and boundary-definition phase.

It is not an implementation-heavy phase.
It is not a reconciliation phase.
It is not an amendment phase.

## Why Phase 33 Exists

The current system protects transport retries through envelope idempotency.

A deferred backlog item already notes that future OTA integrations may
send repeated business events with different request identifiers.

If that behavior exists, envelope-level dedup alone is not enough to prove
business-level idempotency under real OTA retry patterns.

Phase 33 exists to determine the exact gap, verify the current behavior,
and define the safe next hardening step without violating canonical
invariants.

## What Is Already True

The following architectural facts remain locked:

- event_log is append-only
- events are immutable
- booking_state is projection-only
- apply_envelope is the only write authority
- adapters must not read booking_state
- adapters must not reconcile booking history
- adapters must not mutate canonical state
- provider-specific logic must remain isolated from the shared pipeline
- MODIFY remains deterministic reject-by-default

The OTA runtime contract remains:

ingest_provider_event
→ process_ota_event
→ canonical envelope
→ IngestAPI.append_event
→ CoreExecutor.execute
→ apply_envelope

## In Scope

Phase 33 may include only the following categories of work:

1. Discovery and evidence gathering
- inspect current OTA identity fields used across normalized payload,
  canonical envelope, and downstream write path
- identify whether duplicate business facts could arrive with different
  envelope or request identifiers
- verify how the current runtime behaves when business-duplicate OTA events
  differ only in transport identity
- inspect existing business identity constraints already present in the
  system

2. Boundary definition
- determine whether the existing canonical business identity is already
  sufficient for OTA-originated duplicate protection
- if not sufficient, define the smallest safe future hardening target
  without implementing full reconciliation or amendment logic
- document the exact separation between transport idempotency and business
  idempotency

3. Minimal verification work
- add focused tests only if needed to prove current behavior
- add fixtures or helpers only if required to reproduce business-duplicate
  OTA scenarios
- update active docs only if executable evidence justifies the wording

## Out of Scope

Phase 33 must NOT introduce:

- reconciliation logic
- amendment handling
- booking_state reads inside adapters
- direct apply_envelope calls from OTA code
- OTA snapshot fetching
- out-of-order buffering
- new canonical event kinds
- adapter-side mutation
- speculative schema changes without verified need
- reopening Phase 28, 31, or 32 decisions

## Required Questions To Answer

Phase 33 should answer these questions with evidence:

1. Can the same OTA business fact arrive with a different envelope or
request identifier while still representing the same booking lifecycle
change?

2. Which fields currently define OTA business identity in practice?

3. Does the current system already prevent those duplicates safely through
existing canonical identity constraints?

4. If a real gap exists, what is the smallest future-safe hardening shape:
- stronger constraint
- dedicated registry
- explicit business dedup layer
- or no change yet

## Completion Conditions

Phase 33 is complete when:

- the current OTA idempotency boundary is described precisely
- the difference between transport idempotency and business idempotency is
  verified with evidence
- any real verification gap is demonstrated concretely rather than assumed
- the next hardening direction is defined minimally and without violating
  canonical invariants
- no canonical semantic decision is reopened
