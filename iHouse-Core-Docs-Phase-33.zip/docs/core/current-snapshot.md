# iHouse Core – Current Snapshot

Current Phase
Phase 33 – OTA Retry Business Idempotency Discovery

Last Closed Phase
Phase 32 – OTA Ingestion Contract Test Verification


## System Status

The deterministic event architecture remains fully operational.

The canonical database gate (`apply_envelope`) remains the only
authority allowed to mutate booking state.

External systems interact with iHouse Core through the OTA ingestion
boundary and then the canonical core ingest path.


## Phase 32 Result

Phase 32 closed the executable verification loop for the OTA ingestion
runtime contract without changing canonical business semantics.

Phase 32 verified the live runtime handoff as:

ingest_provider_event
→ process_ota_event
→ canonical envelope
→ IngestAPI.append_event
→ CoreExecutor.execute
→ apply_envelope

Phase 32 completed the following:

- added direct tests for thin OTA service entry
- added direct tests for ordered shared OTA pipeline responsibilities
- added direct tests for core ingest rejection of missing executor wiring
- aligned replay verification to the same public ingest contract
- verified no tested OTA runtime path bypasses core ingest or CoreExecutor
- reran relevant smoke and invariant checks successfully

No canonical business semantics changed.

No alternative write path was introduced.

MODIFY remains deterministic reject-by-default.


## Canonical External OTA Events

The canonical OTA lifecycle events remain:

- BOOKING_CREATED
- BOOKING_CANCELED


## Canonical Invariants

Event Store
- event_log is append-only
- events are immutable

State Model
- booking_state is projection-only
- booking_state is derived exclusively from events

Write Authority
- apply_envelope RPC is the only authority allowed to mutate booking state

Replay Safety
- duplicate envelopes must not create new events
- duplicate ingestion must remain idempotent


## Phase 33 Focus

Phase 33 focuses on OTA retry business idempotency discovery.

This phase exists to determine whether OTA-originated duplicate business
events can arrive with different transport identifiers and whether the
current system already protects against that safely.

This phase is for discovery, evidence gathering, and minimal verification
only.

It must not redesign the architecture.

It must not reopen closed semantic decisions.
