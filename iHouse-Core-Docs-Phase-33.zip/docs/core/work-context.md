# iHouse Core – Work Context

## Current Active Phase

Phase 33 – OTA Retry Business Idempotency Discovery


## Last Closed Phase

Phase 32 – OTA Ingestion Contract Test Verification


## Current Objective

Determine whether OTA-originated duplicate business events can bypass the
current envelope-level idempotency model by arriving with different
transport identifiers, and define the minimal safe hardening direction if
a real gap exists.

This phase is a discovery and boundary-definition phase only.

It is not a redesign phase.
It is not a reconciliation phase.
It is not an amendment phase.


## Locked Architectural Reality

The system remains a deterministic domain event execution kernel.

System truth is derived from canonical events.

booking_state is projection-only.

apply_envelope is the only authority allowed to mutate state.

Supabase is canonical.

External systems must never bypass the canonical apply gate.


## Permanent Invariants

- event_log is append-only
- events are immutable
- booking_state is derived from events only
- apply_envelope is the only write authority
- adapters must not read booking_state
- adapters must not reconcile booking history
- adapters must not mutate canonical state
- adapters must not bypass apply_envelope
- provider-specific logic must remain isolated from the shared pipeline
- MODIFY remains deterministic reject-by-default


## Current OTA Runtime Boundary

The verified runtime handoff remains:

ingest_provider_event
→ process_ota_event
→ canonical envelope
→ IngestAPI.append_event
→ CoreExecutor.execute
→ apply_envelope


## Phase 33 Scope

Allowed work:

- inspect OTA business identity fields across payload, envelope, and apply path
- verify whether business-duplicate OTA events can arrive with different
  transport identifiers
- verify current behavior with focused executable evidence
- define the smallest safe future hardening direction only if a real gap exists
- update active docs minimally if evidence justifies it

Disallowed work:

- reconciliation
- amendment handling
- OTA snapshot fetching
- out-of-order buffering
- booking_state reads inside adapters
- alternative write paths
- direct apply_envelope calls from OTA code
- new canonical event kinds
- reopening closed phase decisions


## Immediate Working Rule

Do not redesign the architecture.

Do not reopen closed phases.

Do only the minimum work required to identify whether transport idempotency
and business idempotency are already aligned for OTA-originated events.
