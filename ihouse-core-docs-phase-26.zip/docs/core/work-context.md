# iHouse Core – Work Context

Current Phase  
Phase 26 – OTA Provider Verification

Last Closed Phase  
Phase 25 – OTA Modification Resolution Rules


## Phase 26 Objective

Verify whether OTA providers expose deterministic modification signals
in their official payload schema that could safely support payload-only
interpretation.

This phase does NOT introduce new behavior.

Instead it verifies provider payload capabilities and documents the
semantic guarantees offered by each OTA provider.


## Verification Targets

Booking.com  
Expedia  
Additional OTA providers introduced later


## Verification Rules

A modification event may only be mapped to UPDATE if:

1. The provider payload explicitly proves modification subtype.
2. The interpretation requires no booking_state lookup.
3. The interpretation preserves the one-event → one-envelope rule.


## Expected Outcome

Either:

A deterministic payload-only subset is proven.

or

The canonical ingestion rule remains:

MODIFY  
→ deterministic reject-by-default

