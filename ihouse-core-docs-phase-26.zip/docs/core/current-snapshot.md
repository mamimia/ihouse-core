# iHouse Core – Current Snapshot

System Version  
Phase 26 – OTA Provider Verification (Active)

Last Closed Phase  
Phase 25 – OTA Modification Resolution Rules


## System Status

The deterministic event architecture remains fully operational.

The canonical database gate (`apply_envelope`) remains the only authority
allowed to mutate booking_state.

External systems interact with iHouse Core exclusively through the OTA
ingestion boundary.


## Phase 25 Result

OTA modification events were introduced with explicit semantic
recognition through the event class:

MODIFY

However, provider payload inspection demonstrated that no deterministic
MODIFY → UPDATE subset can currently be proven from the inspected
provider payload structure.

Therefore the canonical ingestion rule remains:

MODIFY  
→ deterministic reject-by-default


## Canonical Invariants

Event Store
- event_log is append-only
- events are immutable

State Model
- booking_state is projection-only
- booking_state is derived exclusively from events

Write Authority
- apply_envelope RPC is the only authority allowed to mutate booking_state

Replay Safety
- duplicate envelopes must not create new events
- duplicate ingestion must remain idempotent


## OTA Boundary Status

The OTA adapter layer performs:

- payload normalization
- semantic classification
- semantic validation
- canonical envelope creation

Adapters must never:

- perform booking_state lookups
- reconcile booking history
- mutate canonical state
- bypass the canonical database gate


## Current Architectural Direction

Future OTA modification handling will occur outside the canonical event
pipeline through a separate recovery layer.

Proposed concept:

OTA Sync Recovery Layer  
(possible future name: Channel Reconciliation Engine)

This layer may perform provider re-fetch and reconciliation operations
while preserving the integrity of the canonical event model.

